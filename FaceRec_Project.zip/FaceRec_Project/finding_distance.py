# find_distance.py
import cv2
import pickle
from sklearn.neighbors import KNeighborsClassifier
import numpy as np

# Load the trained model and data
with open('data/names.pkl', 'rb') as f:
    LABELS = pickle.load(f)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

# Ensure data consistency
min_len = min(FACES.shape[0], len(LABELS))
FACES, LABELS = FACES[:min_len], LABELS[:min_len]

# Train the KNN classifier
knn = KNeighborsClassifier(n_neighbors=5, metric='euclidean')
knn.fit(FACES, LABELS)

# Initialize video and face detector
video = cv2.VideoCapture(0, cv2.CAP_DSHOW)
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')

print("--- Distance Tuning Tool ---")
print("Point the camera at a known person, note the distance.")
print("Point the camera at an unknown person, note the distance.")
print("Press 'q' to quit.")

while True:
    ret, frame = video.read()
    if not ret:
        break
        
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        
        # Get the distance to the single nearest neighbor
        distances, indices = knn.kneighbors(resized_img, n_neighbors=1)
        
        distance = distances[0][0]
        person_name = LABELS[indices[0][0]]
        
        # Display the information on the screen
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        info_text = f"{person_name} (Dist: {distance:.2f})"
        cv2.putText(frame, info_text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)

    cv2.imshow("Distance Tuner", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video.release()
cv2.destroyAllWindows()