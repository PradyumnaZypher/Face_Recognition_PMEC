from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch

def speak(str1):
    speak = Dispatch(("SAPI.SpVoice"))
    speak.Speak(str1)

# ---------------- VIDEO & FACE DETECTOR ---------------- #
video = cv2.VideoCapture(0)
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')

# ---------------- LOAD DATA ---------------- #
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

print("Shape of Faces matrix -->", FACES.shape)
print("Number of Labels -->", len(LABELS))

# Safety check for mismatch
if FACES.shape[0] != len(LABELS):
    print("⚠ Data mismatch detected!")
    min_len = min(FACES.shape[0], len(LABELS))
    FACES = FACES[:min_len]
    LABELS = LABELS[:min_len]
    print("✅ Auto-fixed. Now:")
    print("Faces:", FACES.shape[0], "| Labels:", len(LABELS))

# ---------------- TRAIN MODEL ---------------- #
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# ---------------- LOAD BACKGROUND ---------------- #
imgBackground = cv2.imread("background.png")

COL_NAMES = ['NAME', 'TIME']

# ---------------- AUTO ATTENDANCE LOGIC ---------------- #
attendance_dict = {}   # To store first detection times
marked = set()         # Keep track of already marked names

while True:
    ret, frame = video.read()
    # Resize webcam frame to fit the allocated white area (640x480)
    frame = cv2.resize(frame, (640, 480))

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    current_names = []   # For showing in the purple panel

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        output = knn.predict(resized_img)
        name = str(output[0])
        current_names.append(name)

        ts = time.time()
        date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
        timestamp = datetime.fromtimestamp(ts).strftime("%H:%M-%S")
        exist = os.path.isfile("Attendance/Attendance_" + date + ".csv")

        # Draw rectangle + name on face
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.rectangle(frame, (x, y-40), (x+w, y), (0, 0, 0), -1)
        cv2.putText(frame, name, (x, y-10),
                    cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

        # ---- Attendance ---- #
        if name not in marked:
            if name not in attendance_dict:
                attendance_dict[name] = ts
            else:
                if ts - attendance_dict[name] >= 2:
                    speak(f"Attendance taken for {name}")
                    attendance = [name, timestamp]

                    if exist:
                        with open("Attendance/Attendance_" + date + ".csv", "+a", newline="") as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow(attendance)
                    else:
                        with open("Attendance/Attendance_" + date + ".csv", "+a", newline="") as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow(COL_NAMES)
                            writer.writerow(attendance)

                    marked.add(name)
        else:
            attendance_dict.pop(name, None)

    # Place resized frame inside the white box
    imgBackground[162:162 + 480, 55:55 + 640] = frame

    # # -------- Display Names on Purple Panel -------- #
    # y_offset = 250
    # for i, name in enumerate(current_names):
    #     cv2.putText(imgBackground, f"{i+1}. {name}", (850, y_offset + i*40),
    #                 cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

    cv2.imshow("Frame", imgBackground)

    if cv2.waitKey(1) == ord('q'):
        break

video.release()
cv2.destroyAllWindows()