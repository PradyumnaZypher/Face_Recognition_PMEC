import streamlit as st
import pandas as pd
import os
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from streamlit_autorefresh import st_autorefresh
from streamlit_calendar import calendar

# --- Helper Functions ---
def get_name_column(df):
    """Intelligently guesses the name column from a DataFrame."""
    if df.empty:
        return None
    
    # Common names for a student identifier column
    possible_names = ['name', 'student', 'student name', 'names']
    for col in df.columns:
        if col.strip().lower() in possible_names:
            return col
    # Fallback to the first column if no common name is found
    return df.columns[0]

@st.cache_data
def load_all_attendance():
    """
    Loads, concatenates, and cleans all attendance CSV files.
    """
    attendance_dir = "Attendance"
    if not os.path.exists(attendance_dir):
        os.makedirs(attendance_dir)
        return pd.DataFrame(), 0

    all_files = [os.path.join(attendance_dir, f) for f in os.listdir(attendance_dir) if f.endswith('.csv')]
    if not all_files:
        return pd.DataFrame(), 0

    df_list = []
    for file in all_files:
        try:
            date_str = os.path.basename(file).split('_')[1].replace('.csv', '')
            date_obj = pd.to_datetime(date_str, format="%d-%m-%Y").date()
            
            temp_df = pd.read_csv(file)
            if not temp_df.empty:
                temp_df.rename(columns=lambda c: c.strip().title(), inplace=True)
                temp_df['Date'] = date_obj
                df_list.append(temp_df)
        except (pd.errors.EmptyDataError, IndexError, ValueError):
            continue
            
    if not df_list:
        return pd.DataFrame(), 0
        
    master_df = pd.concat(df_list, ignore_index=True)
    total_days = len(master_df['Date'].unique())
    return master_df, total_days

def convert_df_to_csv(df):
    """Converts a DataFrame to a CSV string for downloading."""
    return df.to_csv(index=False).encode('utf-8')

# --- Page Configuration ---
st.set_page_config(
    page_title="Advanced Attendance Dashboard",
    page_icon="🎓",
    layout="wide"
)

# --- App Title ---
st.title("🎓 Advanced Real-time Attendance Dashboard")

# --- Autorefresh Component ---
st_autorefresh(interval=5000, key="data_refresh")

# --- Load Data ---
all_attendance_df, total_class_days = load_all_attendance()

# --- Sidebar ---
st.sidebar.header("Navigation & Settings")
page = st.sidebar.radio("Go to", ["Dashboard", "Student Report", "Insights"])

name_col = None

if not all_attendance_df.empty:
    available_cols = list(all_attendance_df.columns)
    if 'Date' in available_cols:
        available_cols.remove('Date')
        
    guessed_col = get_name_column(all_attendance_df)
    
    name_col = st.sidebar.selectbox(
        "Select Student Name Column",
        options=available_cols,
        index=available_cols.index(guessed_col) if guessed_col in available_cols else 0
    )
else:
    st.sidebar.info("Upload attendance data to configure settings.")

# --- Main Application ---
if all_attendance_df.empty or name_col is None:
    st.warning("No attendance data found in the 'Attendance' directory. Please add some CSV files.")
    st.stop()

# ===== DASHBOARD PAGE =====
if page == "Dashboard":
    st.header("Dashboard")
    
    # --- Today's Attendance ---
    with st.expander("📅 Today's Attendance", expanded=True):
        
        # Get a master list of all unique students
        all_students_list = sorted(all_attendance_df[name_col].unique())
        total_students_count = len(all_students_list)

        today_file_path = f"Attendance/Attendance_{datetime.now().strftime('%d-%m-%Y')}.csv"
        
        col1, col2 = st.columns(2)

        if os.path.exists(today_file_path):
            try:
                today_df = pd.read_csv(today_file_path)
                today_df.rename(columns=lambda c: c.strip().title(), inplace=True)
            except pd.errors.EmptyDataError:
                today_df = pd.DataFrame() # Create an empty DF if file is empty
        else:
            today_df = pd.DataFrame() # Create an empty DF if file doesn't exist

        if not today_df.empty:
            present_students_list = sorted(today_df[name_col].unique())
            absent_students_list = sorted(list(set(all_students_list) - set(present_students_list)))
            
            # --- PRESENT COLUMN ---
            with col1:
                st.metric("Total Registered Students", f"{total_students_count}")
                st.metric("✅ Students Present Today", f"{len(present_students_list)}")
                st.dataframe(today_df, use_container_width=True)

            # --- ABSENT COLUMN ---
            with col2:
                st.metric("❌ Students Absent Today", f"{len(absent_students_list)}")
                if absent_students_list:
                    absent_df = pd.DataFrame(absent_students_list, columns=[name_col])
                    st.dataframe(absent_df, use_container_width=True)
                else:
                    st.success("All students are present today!")

        else: # Handle case where attendance hasn't started or file is empty
            absent_df = pd.DataFrame(all_students_list, columns=[name_col])
            # --- PRESENT COLUMN ---
            with col1:
                st.metric("Total Registered Students", f"{total_students_count}")
                st.metric("✅ Students Present Today", "0")
                st.info("Attendance has not been recorded for today.")

            # --- ABSENT COLUMN ---
            with col2:
                st.metric("❌ Students Absent Today", f"{total_students_count}")
                st.dataframe(absent_df, use_container_width=True)

    st.markdown("---")

    # --- Date Range Filter ---
    st.subheader("Filter Attendance Records")
    min_date = all_attendance_df['Date'].min()
    max_date = all_attendance_df['Date'].max()

    date_selection = st.date_input(
        "Select date range:",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date,
    )

    if len(date_selection) == 2:
        start_date, end_date = date_selection
        filtered_df = all_attendance_df[
            (all_attendance_df['Date'] >= start_date) & 
            (all_attendance_df['Date'] <= end_date)
        ]
    else:
        start_date, end_date = min_date, max_date
        filtered_df = all_attendance_df.copy()

    # --- All Recorded Attendance Data Section ---
    st.subheader("📚 All Recorded Attendance (Filtered)")
    filtered_df_sorted = filtered_df.sort_values(by=['Date', name_col], ascending=[False, True])
    st.dataframe(filtered_df_sorted, use_container_width=True)

    # --- Download Button ---
    csv = convert_df_to_csv(filtered_df_sorted)
    st.download_button(
        label="📥 Download Filtered Data as CSV",
        data=csv,
        file_name=f'filtered_attendance_{start_date.strftime("%Y-%m-%d")}_to_{end_date.strftime("%Y-%m-%d")}.csv',
        mime='text/csv',
    )


# ===== STUDENT REPORT PAGE =====
elif page == "Student Report":
    st.header("Individual Student Report")
    
    student_list = sorted(all_attendance_df[name_col].unique())
    selected_student = st.selectbox("Select a Student", student_list)

    if selected_student:
        st.subheader(f"Report for: {selected_student}")
        
        student_df = all_attendance_df[all_attendance_df[name_col] == selected_student]
        days_present = len(student_df)
        percentage = (days_present / total_class_days) * 100 if total_class_days > 0 else 0
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Days Present", f"{days_present}")
        col2.metric("Total Class Days", f"{total_class_days}")
        col3.metric("Attendance Percentage", f"{percentage:.2f}%")
        
        st.markdown("---")
        
        st.subheader("🗓️ Attendance Calendar")
        
        events = []
        for index, row in student_df.iterrows():
            events.append({
                "title": "Present",
                "start": row['Date'].isoformat(),
                "end": row['Date'].isoformat(),
                "color": "green",
            })

        calendar_options = {
            "initialView": "dayGridMonth",
            "headerToolbar": {
                "left": "prev,next today",
                "center": "title",
                "right": "dayGridMonth,timeGridWeek"
            },
        }

        calendar(events=events, options=calendar_options, key="student_calendar")

# ===== INSIGHTS PAGE =====
elif page == "Insights":
    st.header("📊 Attendance Insights & Trends")
    
    st.subheader("Key Performance Indicators")
    avg_attendance = all_attendance_df.groupby('Date')[name_col].count().mean()
    
    col1, col2 = st.columns(2)
    col1.metric("Total Class Days Recorded", f"{total_class_days}")
    col2.metric("Average Daily Attendance", f"{avg_attendance:.2f} students")

    st.markdown("---")
    
    st.subheader("🏆 Attendance Leaderboards")
    student_counts = all_attendance_df[name_col].value_counts()
    attendance_percentage = (student_counts / total_class_days) * 100 if total_class_days > 0 else 0
    attendance_df = attendance_percentage.reset_index()
    attendance_df.columns = ['Student', 'Attendance (%)']

    # Sort all students by attendance percentage, not just the top 5
    all_students_sorted = attendance_df.sort_values(by='Attendance (%)', ascending=False)

    st.dataframe(
        all_students_sorted.style.format({'Attendance (%)': "{:.2f}%"}), 
        height=245, 
        use_container_width=True
    )

    st.markdown("---")

    st.subheader("📅 Daily Attendance Trend")
    daily_counts = all_attendance_df.groupby('Date')[name_col].count().reset_index()
    daily_counts.columns = ['Date', 'Present Students']
    
    fig_trend = px.line(
        daily_counts,
        x='Date',
        y='Present Students',
        title='Number of Present Students Over Time',
        markers=True,
        labels={'Present Students': 'Number of Students', 'Date': 'Class Date'}
    )
    fig_trend.update_layout(xaxis_title="Date", yaxis_title="Number of Present Students")
    st.plotly_chart(fig_trend, use_container_width=True)