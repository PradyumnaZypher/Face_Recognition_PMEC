# eval.py
import pickle
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

# ---------------- LOAD DATA ---------------- #
with open('data/names.pkl', 'rb') as f:
    LABELS = pickle.load(f)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

print("Shape of Faces matrix -->", FACES.shape)
print("Number of Labels -->", len(LABELS))

# Safety check
if FACES.shape[0] != len(LABELS):
    print("⚠ Data mismatch detected!")
    min_len = min(FACES.shape[0], len(LABELS))
    FACES = FACES[:min_len]
    LABELS = LABELS[:min_len]

# ---------------- SPLIT DATA ---------------- #
# Train-test split (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(
    FACES, LABELS, test_size=0.2, random_state=42, stratify=LABELS
)

# ---------------- TRAIN MODEL ---------------- #
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

# ---------------- EVALUATION ---------------- #
y_pred = knn.predict(X_test)

acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred, average='weighted', zero_division=0)
rec = recall_score(y_test, y_pred, average='weighted', zero_division=0)
f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
cm = confusion_matrix(y_test, y_pred)

print("\nEvaluation Results:")
print("Accuracy :", acc)
print("Precision:", prec)
print("Recall   :", rec)
print("F1 Score :", f1)
print("\nConfusion Matrix:\n", cm)
print("\nClassification Report:\n", classification_report(y_test, y_pred, zero_division=0))
