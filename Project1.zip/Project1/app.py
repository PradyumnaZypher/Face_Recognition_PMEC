import streamlit as st
import pandas as pd
import os
from datetime import datetime
import plotly.express as px
from streamlit_autorefresh import st_autorefresh
from streamlit_calendar import calendar

# --- Load Attendance Data ---
def load_all_attendance():
    if not os.path.exists("Attendance"):
        os.makedirs("Attendance")
        return pd.DataFrame(), 0

    all_files = [f for f in os.listdir("Attendance") if f.endswith(".csv")]
    if not all_files:
        return pd.DataFrame(), 0

    df_list = []
    for file in all_files:
        try:
            date_str = file.split('_')[1].replace('.csv', '')
            date_obj = pd.to_datetime(date_str, format="%d-%m-%Y").date()
            temp_df = pd.read_csv(os.path.join("Attendance", file))
            if not temp_df.empty:
                temp_df['DATE'] = date_obj
                df_list.append(temp_df)
        except (pd.errors.EmptyDataError, IndexError, ValueError):
            continue

    if not df_list:
        return pd.DataFrame(), 0

    master_df = pd.concat(df_list, ignore_index=True)
    total_days = len(master_df['DATE'].unique())
    return master_df, total_days

def convert_df_to_csv(df):
    return df.to_csv(index=False).encode('utf-8')

# --- Streamlit Config ---
st.set_page_config(
    page_title="Advanced Attendance Dashboard",
    page_icon="🎓",
    layout="wide"
)
st.title("🎓 Advanced Real-time Attendance Dashboard")
st_autorefresh(interval=5000, key="data_refresh")

# --- Load Data ---
all_attendance_df, total_class_days = load_all_attendance()

# --- Sidebar ---
st.sidebar.header("Navigation")
page = st.sidebar.radio("Go to", ["Dashboard", "Student Report", "Insights"])

# --- Stop if no data ---
if all_attendance_df.empty:
    st.warning("No attendance data found in 'Attendance' folder.")
    st.stop()

# ===== DASHBOARD =====
if page == "Dashboard":
    st.header("Dashboard")
    all_students_list = sorted(all_attendance_df["NAME"].unique())
    total_students_count = len(all_students_list)
    
    today_file = f"Attendance/Attendance_{datetime.now().strftime('%d-%m-%Y')}.csv"
    today_df = pd.read_csv(today_file) if os.path.exists(today_file) else pd.DataFrame()

    col1, col2 = st.columns(2)

    if not today_df.empty:
        present_students_list = sorted(today_df["NAME"].unique())
        absent_students_list = sorted(list(set(all_students_list) - set(present_students_list)))

        with col1:
            st.metric("Total Registered Students", f"{total_students_count}")
            st.metric("✅ Students Present Today", f"{len(present_students_list)}")
            st.dataframe(today_df, use_container_width=True)

        with col2:
            st.metric("❌ Students Absent Today", f"{len(absent_students_list)}")
            if absent_students_list:
                st.dataframe(pd.DataFrame(absent_students_list, columns=["NAME"]), use_container_width=True)
            else:
                st.success("All students are present today!")
    else:
        with col1:
            st.metric("Total Registered Students", f"{total_students_count}")
            st.metric("✅ Students Present Today", "0")
            st.info("Attendance has not been recorded today.")

        with col2:
            st.metric("❌ Students Absent Today", f"{total_students_count}")
            st.dataframe(pd.DataFrame(all_students_list, columns=["NAME"]), use_container_width=True)

    st.markdown("---")

    # --- Filter by date ---
    st.subheader("Filter Attendance Records")
    min_date, max_date = all_attendance_df['DATE'].min(), all_attendance_df['DATE'].max()
    date_selection = st.date_input("Select date range:", value=(min_date, max_date), min_value=min_date, max_value=max_date)
    start_date, end_date = date_selection if len(date_selection) == 2 else (min_date, max_date)

    filtered_df = all_attendance_df[(all_attendance_df['DATE'] >= start_date) & (all_attendance_df['DATE'] <= end_date)]
    filtered_df_sorted = filtered_df.sort_values(by=['DATE', 'NAME'], ascending=[False, True])

    st.subheader("📚 All Recorded Attendance (Filtered)")
    st.dataframe(filtered_df_sorted, use_container_width=True)

    csv = convert_df_to_csv(filtered_df_sorted)
    st.download_button(
        label="📥 Download Filtered Data as CSV",
        data=csv,
        file_name=f'filtered_attendance_{start_date}_{end_date}.csv',
        mime='text/csv',
    )

# ===== STUDENT REPORT =====
elif page == "Student Report":
    st.header("Individual Student Report")
    student_list = sorted(all_attendance_df["NAME"].unique())
    selected_student = st.selectbox("Select a Student", student_list)

    if selected_student:
        student_df = all_attendance_df[all_attendance_df["NAME"] == selected_student]
        days_present = len(student_df)
        percentage = (days_present / total_class_days) * 100 if total_class_days else 0

        col1, col2, col3 = st.columns(3)
        col1.metric("Total Days Present", f"{days_present}")
        col2.metric("Total Class Days", f"{total_class_days}")
        col3.metric("Attendance Percentage", f"{percentage:.2f}%")

        st.markdown("---")
        st.subheader("🗓️ Attendance Calendar")

        events = [{"title": "Present", "start": r['DATE'].isoformat(), "end": r['DATE'].isoformat(), "color": "green"} for _, r in student_df.iterrows()]
        calendar(events=events, options={"initialView": "dayGridMonth"}, key="student_calendar")

# ===== INSIGHTS =====
elif page == "Insights":
    st.header("📊 Attendance Insights & Trends")
    avg_attendance = all_attendance_df.groupby('DATE')["NAME"].count().mean()
    
    col1, col2 = st.columns(2)
    col1.metric("Total Class Days Recorded", f"{total_class_days}")
    col2.metric("Average Daily Attendance", f"{avg_attendance:.2f} students")

    st.markdown("---")
    st.subheader("🏆 Attendance Leaderboards")
    attendance_df = (all_attendance_df["NAME"].value_counts() / total_class_days * 100).reset_index()
    attendance_df.columns = ['Student', 'Attendance (%)']
    st.dataframe(attendance_df.sort_values(by='Attendance (%)', ascending=False).style.format({'Attendance (%)': "{:.2f}%"}), use_container_width=True)

    st.markdown("---")
    st.subheader("📅 Daily Attendance Trend")
    daily_counts = all_attendance_df.groupby('DATE')["NAME"].count().reset_index()
    daily_counts.columns = ['DATE', 'Present Students']
    fig_trend = px.line(daily_counts, x='DATE', y='Present Students', markers=True)
    st.plotly_chart(fig_trend, use_container_width=True)

#extra changes
elif page == "Membrane":
    st.header("Take the attendance to the following schedule and the observer should be awaken at the particular moment")
    cummulative_attendance =all_attendance_df.groupby['NAME']("aadhar_upload").count().mean()

    st.markdown("++++")
    