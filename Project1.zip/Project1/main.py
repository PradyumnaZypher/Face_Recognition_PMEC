import cv2
import pickle
import numpy as np
import os
import csv
import time
import threading
from datetime import datetime
from win32com.client import Dispatch
from sklearn.neighbors import KNeighborsClassifier

# ---------------- SETTINGS ---------------- #
DETECTION_SECONDS = 2.0      # seconds of continuous detection to mark attendance
DISTANCE_THRESHOLD = 5000     # KNN distance threshold; adjust for sensitivity

# ---------------- ASYNC SPEAK ---------------- #
def speak_async(message):
    def _speak(msg):
        speaker = Dispatch(("SAPI.SpVoice"))
        speaker.Speak(msg)
    threading.Thread(target=_speak, args=(message,), daemon=True).start()

# ---------------- ASYNC FILE WRITE ---------------- #
def write_attendance_async(filename, row, header=False):
    def _write(file, row_data, header_flag):
        if os.path.isfile(file) and not header_flag:
            with open(file, "a", newline="") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(row_data)
        else:
            with open(file, "a", newline="") as csvfile:
                writer = csv.writer(csvfile)
                if header_flag:
                    writer.writerow(row_data)
                else:
                    writer.writerow(["NAME", "TIME"])
                    writer.writerow(row_data)
    threading.Thread(target=_write, args=(filename, row, header), daemon=True).start()

# ---------------- LOAD MODEL ---------------- #
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

if FACES.shape[0] != len(LABELS):
    min_len = min(FACES.shape[0], len(LABELS))
    FACES = FACES[:min_len]
    LABELS = LABELS[:min_len]

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# ---------------- VIDEO & FACE DETECTOR ---------------- #
video = cv2.VideoCapture(0, cv2.CAP_DSHOW)
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')
imgBackground = cv2.imread("background.png")

# ---------------- ATTENDANCE STORAGE ---------------- #
ts = time.time()
date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
attendance_file = f"Attendance/Attendance_{date}.csv"

marked = set()
attendance_dict = {}    # first detection timestamp
current_detection = {"label": None, "start_time": None}

if os.path.isfile(attendance_file):
    with open(attendance_file, "r") as csvfile:
        reader = csv.reader(csvfile)
        next(reader, None)
        for row in reader:
            if row:
                marked.add(row[0])

# ---------------- MAIN LOOP ---------------- #
while True:
    ret, frame = video.read()
    frame = cv2.resize(frame, (640, 480))
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    detected_label = None
    detected_distance = None

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)

        distances, neighbors = knn.kneighbors(resized_img)
        predicted = knn.predict(resized_img)[0]

        distance = distances[0][0]
        if distance > DISTANCE_THRESHOLD:
            detected_label = "Unknown"
        else:
            detected_label = predicted

        detected_distance = distance

        # Draw face rectangle and label
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.rectangle(frame, (x, y-40), (x+w, y), (0, 0, 0), -1)
        cv2.putText(frame, detected_label, (x+5, y-10),
                    cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

    # ---------------- CONTINUOUS DETECTION LOGIC ---------------- #
    ts_now = time.time()
    if detected_label:
        if detected_label == current_detection["label"]:
            # same label continuing
            elapsed = ts_now - current_detection["start_time"]
            if detected_label != "Unknown" and elapsed >= DETECTION_SECONDS:
                if detected_label not in marked:
                    timestamp = datetime.fromtimestamp(ts_now).strftime("%H:%M-%S")
                    speak_async(f"Attendance taken for {detected_label}")
                    write_attendance_async(attendance_file, [detected_label, timestamp])
                    marked.add(detected_label)
            elif detected_label == "Unknown" and elapsed >= DETECTION_SECONDS:
                speak_async("Unknown person detected. Attendance not taken.")
        else:
            # new label → reset timer
            current_detection["label"] = detected_label
            current_detection["start_time"] = ts_now

    # ---------------- BACKGROUND & DISPLAY ---------------- #
    if imgBackground is not None and imgBackground.shape[0] >= 642 and imgBackground.shape[1] >= 695:
        imgBackground_copy = imgBackground.copy()
        imgBackground_copy[162:162 + 480, 55:55 + 640] = frame

        y_offset = 250
        for i, name in enumerate(sorted(marked)):
            cv2.putText(imgBackground_copy, f"{i+1}. {name}", (850, y_offset + i*40),
                        cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

        cv2.imshow("Attendance System", imgBackground_copy)
    else:
        cv2.imshow("Attendance System", frame)

    if cv2.waitKey(1) == ord('q'):
        break

video.release()
cv2.destroyAllWindows()
