import streamlit as st
import pandas as pd
import os
import time
from datetime import datetime

# Configure the page title
st.set_page_config(page_title="Real-time Attendance Dashboard")

# 1. Implement the auto-refresh mechanism.
# This component simply forces the entire app to re-run every 2 seconds.

from streamlit_autorefresh import st_autorefresh
st_autorefresh(interval=2000, key="attendance_refresh")

# 2. Get the current date to load the correct file.
date = datetime.now().strftime("%d-%m-%Y")
file_path = f"Attendance/Attendance_{date}.csv"

# 3. Load and display the data.
st.header("Real-time Attendance Monitoring")

if os.path.exists(file_path):
    try:
        df = pd.read_csv(file_path)

        # Ensure the DataFrame is not empty before attempting to display.
        if not df.empty:
            # Display the data in a clean, interactive table.
            st.dataframe(df)

            # Optional: Add an information section.
            st.info(f"Dashboard updated at: {datetime.now().strftime('%H:%M:%S')}")
            st.info(f"Total records: {len(df)}")
        else:
            st.warning("No attendance data found for today yet.")
            
    except pd.errors.EmptyDataError:
        st.warning("The attendance file is empty. Please check the data source.")
    except Exception as e:
        st.error(f"An error occurred while loading the data: {e}")
else:
    st.warning("No attendance file found for today. The dashboard is awaiting data.")