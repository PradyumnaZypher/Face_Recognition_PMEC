from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
import threading
from datetime import datetime
from win32com.client import Dispatch

# ---------------- ASYNC SPEAK ---------------- #
def speak_async(message):
    def _speak(msg):
        speaker = Dispatch(("SAPI.SpVoice"))
        speaker.Speak(msg)
    threading.Thread(target=_speak, args=(message,), daemon=True).start()

# ---------------- ASYNC FILE WRITE ---------------- #
def write_attendance_async(filename, row, header=False):
    def _write(file, row_data, header_flag):
        if os.path.isfile(file) and not header_flag:
            with open(file, "+a", newline="") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(row_data)
        else:
            with open(file, "+a", newline="") as csvfile:
                writer = csv.writer(csvfile)
                if header_flag:
                    writer.writerow(row_data)  # header
                else:
                    writer.writerow(["NAME", "TIME"])  # default header
                    writer.writerow(row_data)
    threading.Thread(target=_write, args=(filename, row, header), daemon=True).start()

# ---------------- VIDEO & FACE DETECTOR ---------------- #
video = cv2.VideoCapture(0, cv2.CAP_DSHOW)   # ✅ reduce lag
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')

# ---------------- LOAD DATA ---------------- #
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

# Safety check for mismatch
if FACES.shape[0] != len(LABELS):
    min_len = min(FACES.shape[0], len(LABELS))
    FACES = FACES[:min_len]
    LABELS = LABELS[:min_len]

# ---------------- TRAIN MODEL ---------------- #
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# ---------------- LOAD BACKGROUND ---------------- #
imgBackground = cv2.imread("background.png")

# ---------------- ATTENDANCE STORAGE ---------------- #
ts = time.time()
date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
attendance_file = f"Attendance/Attendance_{date}.csv"

marked = set()
if os.path.isfile(attendance_file):
    with open(attendance_file, "r") as csvfile:
        reader = csv.reader(csvfile)
        next(reader, None)  # skip header
        for row in reader:
            if row:
                marked.add(row[0])

# ---------------- MAIN LOOP ---------------- #
while True:
    ret, frame = video.read()
    frame = cv2.resize(frame, (640, 480))
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        output = knn.predict(resized_img)
        name = str(output[0]) if output[0] in LABELS else "Unknown"

        ts = time.time()
        timestamp = datetime.fromtimestamp(ts).strftime("%H:%M-%S")

        # ---- DRAW rectangle + name ---- #
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.rectangle(frame, (x, y-40), (x+w, y), (0, 0, 0), -1)
        cv2.putText(frame, name, (x+5, y-10),
                    cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

        # ---- Attendance Logic (Non-Blocking) ---- #
        if name == "Unknown":
            speak_async("Unknown person detected. Attendance not taken.")
        else:
            if name not in marked:
                speak_async(f"Attendance taken for {name}")
                write_attendance_async(attendance_file, [name, timestamp])
                marked.add(name)
            else:
                # Less frequent repeat message to avoid spam
                if int(timestamp.split("-")[-1]) % 10 == 0:
                    speak_async(f"The attendance of {name} is already marked.")

    # ✅ Paste processed frame into background
    if imgBackground is not None and imgBackground.shape[0] >= 642 and imgBackground.shape[1] >= 695:
        imgBackground_copy = imgBackground.copy()
        imgBackground_copy[162:162 + 480, 55:55 + 640] = frame

        # -------- Display Marked Attendance -------- #
        y_offset = 250
        for i, name in enumerate(sorted(marked)):
            cv2.putText(imgBackground_copy, f"{i+1}. {name}", (850, y_offset + i*40),
                        cv2.FONT_HERSHEY_DUPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

        cv2.imshow("Attendance System", imgBackground_copy)
    else:
        cv2.imshow("Attendance System", frame) 

    if cv2.waitKey(1) == ord('q'):
        break

video.release()
cv2.destroyAllWindows()